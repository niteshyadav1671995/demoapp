package com.yash.damsapp.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.User;

@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public boolean insert(User user) {
		String sql = "insert into users(first_name,last_name,contact,address,email,loginname,password) values(?,?,?,?,?,?,?)";
		Object[] params = new Object[] { user.getFirst_name(), user.getLast_name(), user.getContact(),
				user.getAddress(), user.getEmail(), user.getLoginname(), user.getPassword() };
		try{
		jdbcTemplate.update(sql, params);
		return true;
		}catch(DataIntegrityViolationException ex){
			return false;
		}
	}

	
}
