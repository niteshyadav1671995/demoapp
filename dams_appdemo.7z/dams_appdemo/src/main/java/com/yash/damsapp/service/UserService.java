package com.yash.damsapp.service;

import com.yash.damsapp.domain.User;

public interface UserService {
public boolean userRegister(User user);
public User checkUserLogin(String loginname,String password,String email);
}
