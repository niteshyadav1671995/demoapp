package com.yash.damsapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String showHelloWorld() {
		return "home";
	}

	@RequestMapping(value = "/userRegister.htm", method = RequestMethod.GET)
	public String showRegistrationForm() {
		return "userRegistration";
	}

	@RequestMapping(value = "/processUserRegistration.htm", method = RequestMethod.POST)
	public String register(@ModelAttribute("user") User user, Model model) {
		boolean userStatus=userService.userRegister(user);
		if(userStatus){
		return "redirect:./hello.htm";
	}else{
		Boolean alert=true;
		model.addAttribute("alert",alert);
		return "userRegistration";
	}
		}

	@RequestMapping(value = "/userLogin.htm", method = RequestMethod.GET)
	public String loginForm() {
		return "userLogin";
	}

	@RequestMapping(value = "/login.htm", method = RequestMethod.GET)
	public String userLogin(@RequestParam String loginname, @RequestParam String password, @RequestParam String email,ModelMap modelmap,Model model ) {
		User checkuser = userService.checkUserLogin(loginname, password, email);
		if (checkuser != null) {
			 model.addAttribute("user",checkuser);
			return "userDashboard";
		} else {
			modelmap.addAttribute("user", checkuser);
			return "userLogin";
		}
	}

}